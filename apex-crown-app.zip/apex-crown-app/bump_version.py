#!/usr/bin/env python3
"""Ship an update:  python3 bump_version.py 1.1.0 "What changed" "Another change"

Updates the version in index.html, sw.js and version.json together, then upload
the folder to your host again. People who have the app installed see an
"Update ready" banner and keep their saved library."""
import json, pathlib, re, sys

if len(sys.argv) < 2 or not re.fullmatch(r"\d+\.\d+\.\d+", sys.argv[1]):
    sys.exit('Usage: python3 bump_version.py 1.1.0 "Release note" ["Another note" ...]')

v, notes = sys.argv[1], sys.argv[2:] or ["Improvements and fixes."]
here = pathlib.Path(__file__).parent

def sub(name, pattern, repl):
    p = here / name
    s = p.read_text()
    new, n = re.subn(pattern, repl, s, count=1)
    if n != 1:
        sys.exit(f"Could not find the version line in {name}")
    p.write_text(new)

sub("index.html", r"var APP_VERSION='[^']*';", f"var APP_VERSION='{v}';")
sub("sw.js", r"const VERSION = '[^']*';", f"const VERSION = '{v}';")
(here / "version.json").write_text(json.dumps({"version": v, "notes": notes}, indent=2) + "\n")
print(f"Version is now {v}. Upload the folder to your host to publish the update.")

# Apex Crown

A music player for your own audio files. Installable, works offline, keeps your library on your device, and updates itself.

## Run it (quickest)

Double-click `index.html` to try it. Playback and the saved library work, but installing and updates need the app to be served over https (next section).

## Install it as an app

An installable app must be served from a web address. Any static host works and most are free: GitHub Pages, Netlify, Cloudflare Pages, Vercel.

1. Upload this whole folder to the host (keep the files together).
2. Open the address in Chrome, Edge or Safari.
3. Install it:
   - Chrome / Edge (desktop and Android): click **Install app** in the version panel (tap `v1.0.0` in the header), or use the install icon in the address bar.
   - iPhone / iPad: Share, then **Add to Home Screen**.

To test on your own computer first, run `python3 -m http.server 8000` in this folder and open `http://localhost:8000`. Localhost counts as secure for installing.

## Add music

Use **Add music**, or drag audio files onto the window. MP3, WAV, OGG, M4A, AAC, FLAC and Opus work if your browser can play them. Files up to 200 MB each. Tracks are copied into the app's own storage on this device. Nothing is uploaded anywhere.

Clearing your browser's site data for this app also clears the library.

## Shipping an update

1. Change what you want in `index.html`.
2. Run `python3 bump_version.py 1.1.0 "What changed"`.
3. Upload the folder to your host again.

Anyone with the app open sees an **Update ready** banner within about 30 minutes, or right away if they tap **Check for updates** in the version panel. They tap **Restart to update**. Their library and settings stay as they were.

## Files

| File | Purpose |
|---|---|
| `index.html` | The whole app |
| `sw.js` | Offline support and update handling |
| `manifest.webmanifest` | Name, icons and colors for installing |
| `version.json` | Latest version and release notes, read by the update check |
| `icons/` | App icons |
| `bump_version.py` | Keeps the version number in sync across files |

## Keyboard

Space play or pause, arrow keys seek 5 seconds, N next, P previous, M mute.
